<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BancoDeDados
 *
 * @author Lu�s Mendes
 */
class BDVenda implements BD{

    function __construct($classe) {

    }

    public function alterar() {
        
    }

    public function cadastrar() {
        
    }

    public function excluir() {
        
    }

    public function buscar() {
        
    }

    

}

?>
