<html>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <link rel="stylesheet" type="text/css" href="http://localhost/SitePapelaria/css/estilo.css">
    <body>

        <div id="divSessao">

            <form method="POST" action="encerraSessao.php">
                <p><a href="http://localhost/SitePapelaria/index.php">Mudar de usu�rio</a></p>
                <p><a href="http://localhost/SitePapelaria/index.php">Sair</a></p>
            </form>
        </div>

    </body>
</html>
