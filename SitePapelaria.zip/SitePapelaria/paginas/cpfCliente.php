<?php

$_POST["cpfCliente"];

?>
