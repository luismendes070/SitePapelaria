<html>
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
        <link rel="stylesheet" type="text/css" href="http://localhost/SitePapelaria/css/estilo.css">
    </head>
    <body>
        <div id="divLogin">
            <form method="POST" action="login.php">

                <p>Nome</p><input type="text" name="nomeUsuario">
                <p>Senha</p><input type="password" name="senha">
                <p><input type="submit" value="login" name="botaoLogin"></p>
                <p><a href="cliente.php">Cadastro de clientes</a></p>

            </form>
        </div>
    </body>
</html>