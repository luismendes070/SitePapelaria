<?php

unset($_SESSION);

?>
