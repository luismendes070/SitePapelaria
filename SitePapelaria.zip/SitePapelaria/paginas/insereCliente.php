<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
        <link rel="stylesheet" type="text/css" href="http://localhost/SitePapelaria/css/estilo.css">
    </head>
    <body>

        <?php
        $conexao = new mysqli("localhost", "root", "", "papelaria2");

        if ($conexao->connect_errno) {
            echo "Erro de conex�o";
        }

        function buscaCPFCadastrado($cpf) {

            $resp = false;

            $conexao = new mysqli("localhost", "root", "", "papelaria2");

            if ($conexao->connect_errno) {
                echo "Erro de conex�o";
            }

            $query = 'SELECT * FROM cliente WHERE cpf ="' . $cpf . '";';


            if ($result = $conexao->query($query)) {

                if ($cpf == $row[0]) {
                    $resp = true;
                    return $resp;
                }
            } else {
                echo '<h1>Erro!<h1>';
            }

            $conexao->close();

            return $resp;
        }

#fim da fun��o buscaCPFCadastrado

        $cpf = $_POST["cpf"];

        if (buscaCPFCadastrado($cpf)) {

            $data_cadastro = $_POST["dataCadastro"];
            $data_nascimento = $_POST["dataNascimento"];
            $rg = $_POST["rg"];
            $telefone = $_POST["telefone"];
            $telefone_loja1 = $_POST["telefoneLoja1"];
            $telefone_loja2 = $_POST["telefoneLoja2"];
            $telefone_loja3 = $_POST["telefoneLoja3"];
            $endereco = $_POST["endereco"];
            $situacao = $_POST["situacao"];
            $nome_loja1 = $_POST["nomeLoja1"];
            $nome_loja2 = $_POST["nomeLoja2"];
            $nome_loja3 = $_POST["nomeLoja3"];
            $nome = $_POST["nome"];



            $query = "
        INSERT INTO 'papelaria2'.'cliente' 
        ('cpf', 
        'data_cadastro', 
        'data_nascimento', 
        'rg', 
        'telefone', 
        'telefone_loja1', 
        'telefone_loja2', 
        'telefone_loja3', 
        'endereco', 
        'situacao', 
        'nome_loja1', 
        'nome_loja2', 
        'nome_loja3', 
        'nome') VALUES (";


            $query .= "
        '$cpf', 
        '$data_cadastro',
        '$data_nascimento',
        '$rg',
        '$telefone',
        '$telefone_loja1',
        '$telefone_loja2',
        '$telefone_loja3',
        '$endereco',
        '$situacao',
        '$nome_loja1',
        '$nome_loja2',
        '$nome_loja3',
        '$nome'
";

            $query .= '");';


            if ($result = $conexao->query($query)) {

                echo '<h1>Agora voc� j� � nosso cliente!<h1>';
            } else {
                echo '<h1>Erro!<h1>';
            }

            $conexao->close();
        } else {
            echo '<h1>Seu CPF ainda n�o est� cadastrado ainda!<h1>';
            echo '<h1>Cadastre-se e retorne aqui!<h1>';
        }
        ?>

    </body>
</html>