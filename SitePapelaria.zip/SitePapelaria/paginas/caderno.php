<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        
        <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
        <link rel="stylesheet" type="text/css" href="http://localhost/SitePapelaria/css/estilo.css">
    </head>
    <body>
        <div>
            <img src="file:///C:/xampp/htdocs/SitePapelaria/imagens/produtos/cadernouniversitariocapadura.jpg" alt="Caderno universit�rio capa dura" width="180" height="180">
        </div>
    </body>
</html>
